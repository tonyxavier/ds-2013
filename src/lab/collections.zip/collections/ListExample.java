package lab.collections;

public class ListExample {

}
