package lab.thread;

public class Account {
	long balance;

}
